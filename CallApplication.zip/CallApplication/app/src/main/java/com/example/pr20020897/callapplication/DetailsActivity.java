package com.example.pr20020897.callapplication;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class DetailsActivity extends AppCompatActivity {
    private static final String TAG = "DetailsActivity";
    
    TextView name , bio;
    ImageView image;
    Long number;
    Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Log.d(TAG, "onCreate: started");
        name = findViewById(R.id.name);
        image = findViewById(R.id.image);
        bio = findViewById(R.id.bio);
        mContext = getApplicationContext();
        getDetails();


        Button whatsapp = findViewById(R.id.whatsapp);
        whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PackageManager packageManager = mContext.getPackageManager();
                Intent sendToWhatsapp = new Intent(Intent.ACTION_VIEW);
                try{
                    String url = "https://api.whatsapp.com/send?phone=91"+number+"&text="+ URLEncoder.encode(bio.getText().toString(),"UTF-8");
                    sendToWhatsapp.setPackage("com.whatsapp");
                    sendToWhatsapp.setData(Uri.parse(url));
                    if(sendToWhatsapp.resolveActivity(packageManager) != null){
                        startActivity(sendToWhatsapp);
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }





            }
        });
        Log.d(TAG, "onCreate: ends");
    }

    private void getDetails(){
        Log.d(TAG, "getDetails: started");
        Intent intent = getIntent();
        String dname = intent.getStringExtra("name");
        int dimageId = intent.getIntExtra("imageId",0);
        String dbio = intent.getStringExtra("bio");
        number = intent.getLongExtra("number",0);
        //--------setting Details ----------------//
        name.setText(dname);
        Glide.with(this)
                .asBitmap()
                .load(dimageId)
                .into(image);
        bio.setText(dbio);
        Log.d(TAG, "getDetails: End");
    }
}
