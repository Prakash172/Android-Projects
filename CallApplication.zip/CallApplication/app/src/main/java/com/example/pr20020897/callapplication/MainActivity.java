package com.example.pr20020897.callapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import javax.security.auth.login.LoginException;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> mNames;
    private ArrayList<Long> numbers;
    private ArrayList<Integer> imageId ;
    private ArrayList<String> mBio;
    Button addNew;
    RecyclerViewAdapter recyclerViewAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageId = new ArrayList<>();
        mNames = new ArrayList<>();
        numbers = new ArrayList<>();
        mBio = new ArrayList<>();
        addNew = findViewById(R.id.addNewFreind);
        addNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addNewIntent = new Intent(getApplicationContext(),AddNewActivity.class);
                startActivity(addNewIntent);
                addNewContact();
            }
        });
        initImageBitmaps();
    }

    private void addNewContact() {
        Intent recieve = getIntent();
        mNames.add(recieve.getStringExtra("name"));
        mBio.add("noithing");
        numbers.add(recieve.getLongExtra("number",0));
        imageId.add(recieve.getIntExtra("imageId",0));
        recyclerViewAdapter.notifyDataSetChanged();
    }


    private void initImageBitmaps() {
        imageId.add(R.drawable.prakash);
        mNames.add("Prakash sharma");
        numbers.add(9971468242L);
        mBio.add("Hello! This is prakash sharma and today i am preparing for the tommorows interview and this app is made up as the part of this prepration");

        imageId.add(R.drawable.jini);
        mNames.add("Jinitha paul");
        numbers.add(8281794273L);
        mBio.add("I am jinitha paul, my friends call me jini, i am from kerla but i love north indian food.");

        imageId.add(R.drawable.avi);
        mNames.add("Avi Aggarwal");
        numbers.add(8979609640L);
        mBio.add("Hey, this is avi aggarwal from kanpur. I am baniya and i'll not spent money on you guys..hahahhahha");

        imageId.add(R.drawable.gayathri);
        mNames.add("Gayatthri sukumaran");
        numbers.add(9746881002L);
        mBio.add("My name is gayathri and i need more food. I am also from kerla and i love north indian food and wines");

        imageId.add(R.drawable.rishi);
        mNames.add("Rishi hanspal");
        numbers.add(9654574542L);
        mBio.add("This is rishi hanspal from punjab. Very soon i came to know the purpose of my life .. that is reproduction....LOL");

        imageId.add(R.drawable.kumfu);
        mNames.add("Kumfu Panda");
        numbers.add(9205909815L);
        mBio.add("Hello, i am kks and i am an independent girl and i like to explore the places");

        initRecyclerViewAdapter();
    }


    private void initRecyclerViewAdapter() {

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerViewAdapter = new RecyclerViewAdapter(this,imageId,mNames,numbers,mBio);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


}
