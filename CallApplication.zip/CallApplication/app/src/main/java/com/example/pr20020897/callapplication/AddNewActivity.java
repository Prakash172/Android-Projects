package com.example.pr20020897.callapplication;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddNewActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 100;
    EditText name;
    EditText number ;
    ImageView image ;
    Button submit,addImage;
    Uri imageUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);
        name = findViewById(R.id.name);
        number = findViewById(R.id.number);
        image = findViewById(R.id.image);
        image.setId(View.generateViewId());
        addImage = findViewById(R.id.addimage);
        submit = findViewById(R.id.submit);
        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGallary();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addNewIntent = new Intent(getApplicationContext(),MainActivity.class);
                if(isValid(number.getText().toString())){
                    addNewIntent.putExtra("name",name.getText().toString());
                    addNewIntent.putExtra("number",Long.parseLong(number.getText().toString()));
                    addNewIntent.putExtra("imageId",image.getId());
                    startActivity(addNewIntent);
                    }
                else Toast.makeText(getApplicationContext(),"Enter valid phone number without, 0,91,+",Toast.LENGTH_LONG).show();

            }
        });


    }

    private void openGallary() {
        Intent imageIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(imageIntent,PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode==PICK_IMAGE){
            imageUri = data.getData();
            image.setImageURI(imageUri);
        }
    }

    public static boolean isValid(String s)
    {
        Pattern p = Pattern.compile("[7-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }
}
