package com.example.pr20020897.callapplication;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by PR20020897 on 8/25/2018.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{
    private static final String TAG = "RecyclerViewAdapter";
    private Context mContext;
    private ArrayList<Integer> mImageUrl;
    private ArrayList<String> mName ;
    private ArrayList<Long> mNumber ;
    private ArrayList<String> mBio;

    RecyclerViewAdapter(Context mContext, ArrayList<Integer> mImageUrl, ArrayList<String> mName, ArrayList<Long> mNumber,ArrayList<String> mBio) {
        this.mContext = mContext;
        this.mImageUrl = mImageUrl;
        this.mName = mName;
        this.mNumber = mNumber;
        this.mBio = mBio;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: started");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem_view,parent,false);
        ViewHolder holder = new ViewHolder(view);
        Log.d(TAG, "onCreateViewHolder: end");
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        Log.d(TAG, "onBindViewHolder: started");


        Glide.with(mContext)
                .asBitmap()
                .load(mImageUrl.get(position))
                .into(holder.image);
        holder.name.setText(mName.get(position));
        holder.callButton.setBackgroundResource(R.drawable.ic_call_black_24dp);
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentForDetails = new Intent(mContext,DetailsActivity.class);
                intentForDetails.putExtra("name",mName.get(position));
                intentForDetails.putExtra("imageId",mImageUrl.get(position));
                intentForDetails.putExtra("bio",mBio.get(position));
                intentForDetails.putExtra("number",mNumber.get(position));
                mContext.startActivity(intentForDetails);
                Log.d(TAG, "onClick: parent is clicked");
            }
        });
        holder.callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "onClick: Call button pressed");
                dialNumber(position);
            }
        });
        Log.d(TAG, "onBindViewHolder: ends");
    }

    // It's Working now
        private void dialNumber(int position) {

        // Use format with "tel:" and phone number to create phoneNumber.
        String phoneNumber = String.format("tel: %s",
                mNumber.get(position).toString());
        // Create the intent.
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse(phoneNumber));

        if (ActivityCompat.checkSelfPermission(mContext,
                Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            mContext.startActivity(callIntent);
        }else Log.d(TAG, "dialNumber: call cannot ne completed");

    }
    @Override
    public int getItemCount() {
        return mImageUrl.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        CircleImageView image;
        TextView name;
        Button callButton;
        RelativeLayout parent;
        ViewHolder(View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            callButton = itemView.findViewById(R.id.callButton);
            parent = itemView.findViewById(R.id.parent);
        }
    }
}
