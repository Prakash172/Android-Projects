package com.example.pr20020897.timestableapp;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    SeekBar seekBar;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- seek bar code starts
        seekBar = findViewById(R.id.seekBar);


        seekBar.setMax(20);
        seekBar.setProgress(5);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                int min = 1;
                int times ;
                if(i < min) {
                    times = min;
                    seekBar.setProgress(times);
                }
                else times = i;
                getTimesTable(times);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        getTimesTable(5);

    }

    private void getTimesTable(int times) {
        // --seek bar code ends here
        listView = findViewById(R.id.listView);
        ArrayList<Integer> numbers = new ArrayList();
        for(int i =  1 ; i < 11 ; i++){
            numbers.add(i*times);
        }

        listView.setBackgroundColor(Color.GREEN);
        ArrayAdapter<Integer> arrayAdapter = new ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,numbers);
        listView.setAdapter(arrayAdapter);
    }
}
