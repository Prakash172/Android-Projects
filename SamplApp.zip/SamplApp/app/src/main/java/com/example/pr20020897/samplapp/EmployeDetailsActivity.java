package com.example.pr20020897.samplapp;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class EmployeDetailsActivity extends AppCompatActivity {
    private static final String TAG = "EmployeDetailsActivity";

    TextView name ;
    RadioButton rb;
    RadioGroup rg;
    Calendar calendar;
    Spinner department;
    TextView income;
    TextView mobileNumber,dateDisplay;
    private int year, month, day;
    Button submit,displayAllData;
    DataModel model;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employe_details);
        rg = findViewById(R.id.radio_group);
        name = findViewById(R.id.name_input);
        calendar = Calendar.getInstance();
        department = findViewById(R.id.depart_input);
        income = findViewById(R.id.income_input);
        mobileNumber = findViewById(R.id.mobile_input);
        submit = findViewById(R.id.submit);
        dateDisplay = findViewById(R.id.dateDisplay);
        displayAllData = findViewById(R.id.displayAllData);
        model = new DataModel();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        dateDisplay.setText(String.valueOf(day+"/"+month+"/"+year));
        databaseCode();
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validateControls()){
                int id = rg.getCheckedRadioButtonId();
                if(id == -1){
                    Toast.makeText(getApplicationContext(),"Please select gender",Toast.LENGTH_SHORT).show();
                }else{
                    rb = findViewById(id);
                    sendDataToBeDisplay();
                }}
                else{
                    Toast.makeText(getApplicationContext(),"Please enter the fields, like name,phone number,department",Toast.LENGTH_LONG).show();
                }

            }
        });
        displayAllData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),DisplayAllDataActivity.class);
                startActivity(i);

            }
        });

    }
    private void databaseCode(){
        try {
            SQLiteDatabase database = this.openOrCreateDatabase("Employee", MODE_PRIVATE, null);
            database.execSQL("CREATE TABLE IF NOT EXISTS employee(name VARCHAR,number VARCHAR)");
            database.execSQL("INSERT INTO employee(name,number) VALUES('"+name.getText().toString()+"',"+mobileNumber.getText().toString()+")");


            Cursor c = database.rawQuery("SELECT * FROM employee",null);
            c.moveToFirst();

            int nameIndex = c.getColumnIndex("name");
            int numberIndex = c.getColumnIndex("number");
            while(c!= null){
                DataModel.nameDataList.add(c.getString(nameIndex));
                DataModel.numberDataList.add(c.getString(numberIndex));

                Log.i(TAG, "databaseCode: "+c.getString(nameIndex) + "---" + c.getString(numberIndex));
                c.moveToNext();
            }


            c.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void sendDataToBeDisplay(){
        Intent display = new Intent(getApplicationContext(),DisplayActivity.class);
        display.putExtra("name",name.getText().toString());
        display.putExtra("gender",rb.getText().toString());
        display.putExtra("income",income.getText().toString());
        display.putExtra("dob",String.valueOf(day+"/"+month+"/"+year));
        display.putExtra("department",department.getSelectedItem().toString());
        display.putExtra("mobile",mobileNumber.getText().toString());
        startActivity(display);
    }

    public void setDate(View view) {
        showDialog(999);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,int syear, int smonth, int sday) {
                    year = syear;
                    month = smonth+1;
                    day = sday;
                    dateDisplay.setText(String.valueOf(day+"/"+month+"/"+year));

                }
            };


//

    private boolean validateControls(){
        return !(name.getText().toString().equals("") || mobileNumber.getText().toString().equals("") || department.getSelectedItem() == null);
    }
}
