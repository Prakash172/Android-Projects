package com.example.pr20020897.samplapp;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FlashActivity extends AppCompatActivity {


    private static final long SPLASH_TIME = 3000 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flash);

        Handler handler = new Handler();
        Runnable run = new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(getApplicationContext(),EmployeDetailsActivity.class);
                startActivity(i);
                finish();
            }
        };
        handler.postDelayed(run,SPLASH_TIME);
    }
}
