package com.example.pr20020897.samplapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by PR20020897 on 8/27/2018.
 */

public class ListAdapter extends ArrayAdapter<String> {
    private ArrayList<String> mNames,mNumbers;
    private Context context;

    ListAdapter(Context context, ArrayList<String> mNames, ArrayList<String> mNumbers) {
        super(context, R.layout.list_item);
        this.mNames = mNames;
        this.mNumbers = mNumbers;
    }
    @NonNull
    public View getView(int position, View view, @NonNull ViewGroup parent) {

        @SuppressLint("ViewHolder") View rowView = LayoutInflater.from(context).inflate(R.layout.list_item, parent,false);

        TextView name = rowView.findViewById(R.id.name);
        TextView number = rowView.findViewById(R.id.number);
        name.setText(mNames.get(position));
        number.setText(mNumbers.get(position));

        return rowView;

    };
}
