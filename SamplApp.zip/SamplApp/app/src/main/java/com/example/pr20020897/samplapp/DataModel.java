package com.example.pr20020897.samplapp;

import java.util.ArrayList;

/**
 * Created by PR20020897 on 8/27/2018.
 */

class DataModel {
    static ArrayList<String> nameDataList;
    static ArrayList<String> numberDataList;

    DataModel() {
        nameDataList = new ArrayList<>();
        nameDataList.add("prakash");
        numberDataList = new ArrayList<>();
        numberDataList.add("9971468242");
    }
}
