package com.example.pr20020897.samplapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        Intent display = getIntent();
        String name = display.getStringExtra("name");
        String Gender = display.getStringExtra("gender");
        String Income = display.getStringExtra("income");
        String dob = display.getStringExtra("dob");
        String department = display.getStringExtra("department");
        String mobile = display.getStringExtra("mobile");

        TextView displayText = findViewById(R.id.display);
        displayText.setText(displayText.getText().toString()+ "\n" +name+ "\n" + Gender+ "\n" +Income+ "\n" +dob+ "\n" +department+ "\n" +mobile);

        Button ok = findViewById(R.id.okbtn);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // it works like back button.
            }
        });
    }
}
