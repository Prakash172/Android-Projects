package com.example.pr20020897.samplapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class DisplayAllDataActivity extends AppCompatActivity {
    private static final String TAG = "DisplayAllDataActivity";
    ArrayList<String> mNames,mNumbers;
    DataModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_all_data);
        mNames = new ArrayList<>();
        mNumbers = new ArrayList<>();
        model = new DataModel();
        mNumbers = DataModel.numberDataList;
        mNames = DataModel.nameDataList;
        ListView list = findViewById(R.id.listView);
        ListAdapter adapter = new ListAdapter(this,mNames,mNumbers);
        list.setAdapter(adapter);

    }
}
