package com.example.pr20020897.friends;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText username = findViewById(R.id.username);
        final EditText password = findViewById(R.id.password);

//        final Spinner names = findViewById(R.id.spinner);
//        names.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//                username.setText(names.getSelectedItem().toString());
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> adapterView) {
//
//            }
//        });
        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username.getText().toString().equals("prakash") && password.getText().toString().equals("pk1234")){
                    Log.i("username",username.getText().toString());
                    Toast.makeText(MainActivity.this,username.getText().toString(),Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Log.i("Error","Data is invalid");
                    Toast.makeText(MainActivity.this,"Data is invalid",Toast.LENGTH_LONG).show();
                }
            }
        });

        // list view work
        final ListView namesList = findViewById(R.id.names);
        String[] nameArrayList = getResources().getStringArray(R.array.names);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,nameArrayList);
        namesList.setAdapter(arrayAdapter);
        namesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //l = id, i = position, these are generally same but can be different some times
                username.setText(namesList.getItemAtPosition(i).toString());

            }
        });
    }
}
